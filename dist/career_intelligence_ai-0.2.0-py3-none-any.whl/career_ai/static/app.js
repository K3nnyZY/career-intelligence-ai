"use strict";
const el = (id) => document.getElementById(id);
const labels = {required: "Obligatorias", desirable: "Deseables", unspecified: "Sin clasificación explícita"};
let reviewedText = null;
let busy = false;
let generation = 0;
let pending = null;

function node(tag, text, className) {
  const element = document.createElement(tag);
  if (text !== undefined) element.textContent = text;
  if (className) element.className = className;
  return element;
}

function message(text, error = false) {
  el("status").textContent = text;
  el("status").className = error ? "error" : "";
}

function refreshButtons() {
  el("review").disabled = busy || !el("cv-text").value.trim();
  el("cv-file").disabled = busy;
  el("cv-text").readOnly = busy;
  el("job-text").readOnly = busy;
  el("confirmed").disabled = busy;
  el("skills").querySelectorAll("input").forEach((input) => { input.disabled = busy; });
  el("compare").disabled = busy || reviewedText !== el("cv-text").value ||
    !el("confirmed").checked || !el("job-text").value.trim();
}

async function run(url, options, render) {
  pending?.abort();
  pending = new AbortController();
  const ticket = ++generation;
  busy = true;
  refreshButtons();
  message("Procesando en este equipo…");
  try {
    const response = await fetch(url, {...options, signal: pending.signal, cache: "no-store"});
    const data = await response.json();
    if (ticket !== generation) return;
    if (!response.ok) throw new Error(typeof data.detail === "string" ? data.detail : "No se pudo procesar la solicitud.");
    render(data);
  } catch (error) {
    if (ticket === generation && error.name !== "AbortError") message(error.message || "No se pudo conectar con el servidor local.", true);
  } finally {
    if (ticket === generation) {
      pending = null;
      busy = false;
      refreshButtons();
    }
  }
}

function jsonOptions(body) {
  return {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)};
}

function renderProfile(profile) {
  el("cv-text").value = profile.text;
  reviewedText = profile.text;
  el("skills").replaceChildren();
  for (const skill of profile.skills) {
    const label = node("label");
    const checkbox = node("input");
    checkbox.type = "checkbox";
    checkbox.checked = true;
    checkbox.value = skill;
    checkbox.addEventListener("change", () => {
      el("confirmed").checked = false;
      el("results").hidden = true;
      refreshButtons();
    });
    label.append(checkbox, node("span", skill));
    el("skills").append(label);
  }
  if (!profile.skills.length) el("skills").append(node("p", "No se reconocieron habilidades. Revisa el texto; el diccionario puede omitir tecnologías.", "hint"));
  el("experience").replaceChildren(...profile.experience_signals.map((signal) => node("blockquote", signal.quote)));
  if (!profile.experience_signals.length) el("experience").append(node("p", "No se detectaron fragmentos de experiencia con estas reglas. Puedes revisar tu experiencia directamente en el texto."));
  el("profile-warnings").replaceChildren(...profile.warnings.map((warning) => node("p", warning)));
  el("profile").hidden = false;
  el("results").hidden = true;
  el("confirmed").checked = false;
  message("Extracción lista. Revisa el texto y confirma las habilidades antes de comparar.");
}

function renderEvidence(items, parent) {
  const quotes = [...new Set(items.map((item) => item.quote))];
  for (const quote of quotes) parent.append(node("blockquote", quote));
}

function renderComparison(result) {
  el("summary").replaceChildren();
  for (const [key, group] of Object.entries(result.groups)) {
    const card = node("article");
    const total = group.matched.length + group.missing_evidence.length;
    card.append(node("p", labels[key]), node("strong", total ? `${group.matched.length} / ${total}` : "Sin menciones"),
      node("p", total ? `${Math.round(group.coverage * 100)}% de cobertura reconocida` : "No se calcula cobertura"));
    el("summary").append(card);
  }
  el("result-warnings").replaceChildren(...result.warnings.map((warning) => node("p", warning)));
  el("matches").replaceChildren();
  for (const row of result.skills) {
    const item = node("article", undefined, "match-row");
    const title = node("div", undefined, "match-title");
    title.append(node("h3", row.skill), node("span", labels[row.requirement], "badge"),
      node("span", row.status === "matched" ? "Coincide" : "Sin evidencia en el CV", row.status === "matched" ? "badge" : "badge missing"));
    const evidence = node("div", undefined, "evidence-grid");
    const cv = node("div");
    cv.append(node("h4", "CV revisado"));
    if (row.cv_evidence.length) renderEvidence(row.cv_evidence, cv);
    else cv.append(node("p", "No hay una mención seleccionada que respalde esta habilidad.", "hint"));
    const job = node("div");
    job.append(node("h4", "Vacante"));
    renderEvidence(row.vacancy_evidence, job);
    evidence.append(cv, job);
    item.append(title, evidence);
    el("matches").append(item);
  }
  el("highlights").replaceChildren();
  for (const highlight of result.highlights) {
    el("highlights").append(node("p", `Relevante para: ${highlight.relevant_skills.join(", ")}`, "hint"), node("blockquote", highlight.quote));
  }
  if (!result.highlights.length) el("highlights").append(node("p", "No se detectaron fragmentos de experiencia relacionados con las coincidencias. Revisa manualmente los proyectos relevantes.", "hint"));
  el("excluded").replaceChildren();
  renderEvidence(result.excluded_mentions, el("excluded"));
  if (!result.excluded_mentions.length) el("excluded").append(node("p", "No se detectaron menciones negadas."));
  el("results").hidden = false;
  el("results-heading").focus();
  message("Comparación lista. Los fragmentos del CV corresponden al texto que revisaste.");
}

el("cv-file").addEventListener("change", () => {
  const file = el("cv-file").files[0];
  if (!file) return;
  const format = file.name.split(".").pop().toLowerCase();
  // Reset the native input so the file reference is not retained after upload.
  el("cv-file").value = "";
  reviewedText = null;
  el("confirmed").checked = false;
  el("results").hidden = true;
  el("profile").hidden = true;
  refreshButtons();
  if (!["pdf", "docx"].includes(format) || file.size > 5 * 1024 * 1024 || !file.size) {
    message("Selecciona un PDF o DOCX de entre 1 byte y 5 MiB.", true);
    return;
  }
  run("/documents/extract", {method: "POST", headers: {"Content-Type": "application/octet-stream", "X-Document-Format": format}, body: file}, renderProfile);
});
el("review").addEventListener("click", () => run("/profile/review", jsonOptions({text: el("cv-text").value}), renderProfile));
el("compare").addEventListener("click", () => {
  const selected = [...el("skills").querySelectorAll("input:checked")].map((input) => input.value);
  run("/compare", jsonOptions({cv_text: reviewedText, vacancy_text: el("job-text").value, selected_skills: selected}), renderComparison);
});
el("cv-text").addEventListener("input", () => {
  reviewedText = null;
  el("confirmed").checked = false;
  el("profile").hidden = true;
  el("results").hidden = true;
  refreshButtons();
});
el("job-text").addEventListener("input", () => { el("results").hidden = true; refreshButtons(); });
el("confirmed").addEventListener("change", refreshButtons);
function clearSession(announce = true) {
  ++generation;
  pending?.abort();
  pending = null;
  reviewedText = null;
  busy = false;
  for (const id of ["cv-text", "job-text", "cv-file"]) el(id).value = "";
  for (const id of ["skills", "experience", "profile-warnings", "summary", "matches", "result-warnings", "highlights", "excluded"]) el(id).replaceChildren();
  el("profile").hidden = true;
  el("results").hidden = true;
  el("confirmed").checked = false;
  message(announce ? "Sesión borrada. La aplicación no mantiene archivos ni perfiles guardados." : "");
  refreshButtons();
}
el("clear").addEventListener("click", () => clearSession());
window.addEventListener("pagehide", () => clearSession(false));
window.addEventListener("pageshow", (event) => { if (event.persisted) clearSession(false); });
clearSession(false);
